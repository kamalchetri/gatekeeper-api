console.log("🛡️ VIGIL Shield Active");

document.addEventListener('paste', async (e) => {
  const clipboardData = e.clipboardData || window.clipboardData;
  const pastedText = clipboardData.getData('text');

  // Skip short texts
  if (!pastedText || pastedText.length < 10) return;

  // Get API Key
  chrome.storage.sync.get(['vigil_api_key'], async (result) => {
    if (!result.vigil_api_key) return; 

    // STOP the paste immediately
    e.preventDefault(); 

    try {
      // ✅ FIXED URL: Added /v1/firewall
      const response = await fetch('https://gatekeeper-api-20u0.onrender.com/v1/firewall', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${result.vigil_api_key}`
        },
        body: JSON.stringify({ prompt: pastedText, source: "Chrome Extension" })
      });
      
      const data = await response.json();

      if (data.status === 'ALLOWED') {
        // Safe! Insert text manually
        document.execCommand('insertText', false, pastedText);
      } else {
        // BLOCKED! 🚨
        alert(`🚨 VIGIL BLOCKED THIS PASTE!\n\nReason: ${data.reason}\nRisk Score: ${data.risk_score}/100`);
      }
    } catch (err) {
      console.log("Vigil Server Error or Offline. Allowing paste.");
      // If server fails, allow paste (Fail Open)
      document.execCommand('insertText', false, pastedText); 
    }
  });
});