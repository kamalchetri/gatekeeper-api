// 1. On startup, check if we already have a key
document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.sync.get(['vigil_api_key'], (result) => {
        if (result.vigil_api_key) {
            document.getElementById('apiKey').value = result.vigil_api_key;
            document.getElementById('status').style.display = 'block';
            document.getElementById('status').innerText = "✅ System Active & Connected";
            document.getElementById('saveBtn').innerText = "Update Key";
        }
    });
});

// 2. Save key when clicked
document.getElementById('saveBtn').addEventListener('click', () => {
    const key = document.getElementById('apiKey').value;
    if (key) {
        chrome.storage.sync.set({ vigil_api_key: key }, () => {
            const status = document.getElementById('status');
            status.style.display = 'block';
            status.innerText = "✅ Saved!";
            setTimeout(() => {
                status.innerText = "✅ System Active & Connected";
            }, 1000);
        });
    }
});